function acceptCookies(){localStorage.setItem('nowup_cookies','1');const e=document.getElementById('cookie');if(e)e.remove()}
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('form[action*="/excluir"]').forEach(form=>form.addEventListener('submit',event=>{
    if(!window.confirm('Tem certeza que deseja excluir? Essa ação não poderá ser desfeita.'))event.preventDefault();
  }));
  document.querySelectorAll('form[action*="/editar"]').forEach(form=>{
    const fields=[...form.querySelectorAll('input,select,textarea')];
    const save=form.querySelector('button[type="submit"],button:not([type])');
    if(!fields.length||!save)return;
    fields.forEach(field=>field.disabled=true);save.hidden=true;
    const edit=document.createElement('button');edit.type='button';edit.className='btn soft';edit.textContent='Editar';
    edit.addEventListener('click',()=>{fields.forEach(field=>field.disabled=false);save.hidden=false;edit.hidden=true;const first=fields.find(field=>field.type!=='hidden');if(first)first.focus()});
    form.prepend(edit);
  });
  if(localStorage.getItem('nowup_cookies')){const e=document.getElementById('cookie');if(e)e.remove()}
  const slider=document.querySelector('[data-slider]');
  if(!slider)return;
  const slides=[...slider.querySelectorAll('.ad-slide')],dots=[...slider.querySelectorAll('[data-slide]')],prev=slider.querySelector('[data-prev]'),next=slider.querySelector('[data-next]');
  let current=0,timer;
  const show=i=>{current=(i+slides.length)%slides.length;slides.forEach((s,n)=>s.classList.toggle('active',n===current));dots.forEach((d,n)=>d.classList.toggle('active',n===current))};
  const start=()=>{clearInterval(timer);if(slides.length>1)timer=setInterval(()=>show(current+1),Number(slider.dataset.interval)||5000)};
  dots.forEach((d,i)=>d.addEventListener('click',()=>{show(i);start()}));
  if(prev)prev.addEventListener('click',()=>{show(current-1);start()});
  if(next)next.addEventListener('click',()=>{show(current+1);start()});
  let touchX=0;
  slider.addEventListener('touchstart',e=>{touchX=e.changedTouches[0].screenX;clearInterval(timer)},{passive:true});
  slider.addEventListener('touchend',e=>{const distance=e.changedTouches[0].screenX-touchX;if(Math.abs(distance)>45)show(current+(distance<0?1:-1));start()},{passive:true});
  slider.addEventListener('mouseenter',()=>clearInterval(timer));slider.addEventListener('mouseleave',start);start();
})
